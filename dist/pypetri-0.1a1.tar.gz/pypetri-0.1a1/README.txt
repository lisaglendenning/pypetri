
To install:

python setup.py install

or, if you have paver installed:

paver install
